public class Fibonaccinumbers {
    public static void main(String[] args) {
        int a=1;
        int b =1;

        System.out.println(a+""+b);
        int c;
        for (int i=1;i<34;i++);
            c=a+b;
            System.out.println(""+c);
            a=b;
            b=c;
    }
}
