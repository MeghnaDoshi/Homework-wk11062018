public class Sequence {
    public static void main(String[] args) {
        for(int d=1;d<=10;d++){
            System.out.println(d*d +" ");
        }
    }
}
