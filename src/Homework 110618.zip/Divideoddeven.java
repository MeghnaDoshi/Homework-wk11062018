public class Divideoddeven {
    public static void main(String[] args) {
        System.out.println("Even numbers");
        for (int a = 1; a <= 70; a++) {

            ;
        }
        System.out.println("Odd numbers");
        for (int a = 1; a <= 70; a++) {


        }

    }
    }