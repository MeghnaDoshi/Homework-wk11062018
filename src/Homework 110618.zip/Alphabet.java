
import java.util.Scanner;

public class Alphabet {

    public static void main(String[] args) {
        String charLower ,charUpper;
        Scanner sc = new Scanner(System.in);

        System.out. println("Enter letter in uppercase : ");
        charLower = sc.nextLine();

        charUpper = charLower.toLowerCase();
        System.out.println("Enter letter in Lowercase : "+ charUpper);

        }


    }

