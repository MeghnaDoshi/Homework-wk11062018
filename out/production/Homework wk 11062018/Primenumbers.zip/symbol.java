import java.util.Scanner;

public class symbol
{
    public static void main(String[] args) {

        System.out.println("Enter a value");
        Scanner sc  = new Scanner (System.in);
        char ch=sc.next().charAt(0);


        



    }
}
