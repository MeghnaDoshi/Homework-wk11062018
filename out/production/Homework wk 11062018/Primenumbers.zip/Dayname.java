import java.util.Scanner;

public class Dayname {
    public static void main(String[] args) {


    }

}


