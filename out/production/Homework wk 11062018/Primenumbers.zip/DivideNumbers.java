public class DivideNumbers {
    public static void main(String[] args) {
        System.out.println("n divided by 3");
        for (int a=1;a<100;a++){
         if(a%3==0)
                 System.out.print(a+",");
            if (a % 3 == 0)
                System.out.println(a);
        }
        System.out.println("n divided by 5");
        for (int a=1;a<=100; a++){
            if (a % 5==0)
                System.out.println(a);
        }
    }
        }





