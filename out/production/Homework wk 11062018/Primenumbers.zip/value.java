import java.util.Scanner;

public class value
{
    public static void main(String[] args) {
       int d =20;
       int e =40;

    System.out.println("before :d = "+d+", e= "+e+"");

    d =d+e;
    e= d-e;
        switch (d = d - e) {
        }

    System.out.println("after: d="+d+", e= "+e+" ");


    }
}
