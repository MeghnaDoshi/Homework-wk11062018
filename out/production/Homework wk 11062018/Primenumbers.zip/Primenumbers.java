public class Primenumbers

{
    public static void main(String[] args) {
        int a,b,c;
        for (a =1; a<100;a++);{
         b=0;
        for (c=2; c<a; c++);{
            if (a % c ==0);
                {
                    b = 1;
                }
           }
           }
          if (b ==0);

            {
                System.out.println(a);
            }




        }


    }


