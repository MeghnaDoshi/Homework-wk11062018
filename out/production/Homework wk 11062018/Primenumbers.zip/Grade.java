import java.util.Scanner;

public class Grade
{
    public static void main(String[] args) {

    }
}
